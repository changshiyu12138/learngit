#include"reg51.h"
#define uint unsigned int
#define uchar unsigned char

sbit settime=P1^0;		//����ʱ��
sbit setatime=P1^2;		//��������
sbit inc=P1^4;			//��1
sbit dec=P1^6;			//��1

uchar KeyValue=0;		//ɨ��ʶ��������ĸ���
uchar settype=0;		//0������״̬��1�޸��룬2�޸ķ֣�3�޸�ʱ
uchar alarmtype=0;		//0������״̬��1�޸��룬2�޸ķ֣�3�޸�ʱ


uchar code seg7[]={0x3f,0x06,0x5b,0x4f,
				   0x66,0x6d,0x7d,0x07,
				   0x7f,0x6f,0x40};				//0123456789-


uchar count=0;			//��ʾһ���ж���������Ҫ��ʱ��50ms

sbit led=P1^7;
sbit sled=P1^5;


//ʱ��
uchar s=59,m=23,h=14;			//ʱ�ӳ�ʼֵ
uchar as=3,am=24,ah=14;		//���ӳ�ʼֵ

void delay_ms(uint z) 		//��ʱ����
{
	int x,y;
	for(x=z;x>0;x--)
		for(y=120;y>0;y--);
}

void TimeTim()
{
	if(settype==0 && KeyValue==0)
	{
		if(count==20)
		{
			count=0;
			s++;
			led=~led;
			if(s==60)
			{
				s=0;
				m++;
				if(m==60)
				{
					m=0;
					h++;
					if(h==24)
					{
						h=0;
					}
				}
			}
		}
	}
}


void bsp_CheckAlarm()
{
	if((h==ah)&&(s==as)&&(m==am))
	{
		sled=~sled;
	}
	else if((h==ah)&&(s==as+10)&&(m==am))
	{
		sled=~sled;
	}
}

//����ɨ��
void bsp_KeyScan()
{
	if(settime==0)
	{
		KeyValue=1;
		while(!settime);
	}
	if(setatime==0)
	{
		KeyValue=2;
		while(!setatime);
	}
	if(inc==0)
	{
		KeyValue=3;
		while(!inc);
	}
	if(dec==0)
	{
		KeyValue=4;
		while(!dec);
	}
}

//����KeyValue��ֵ���е���

void timeinc()
{
	if(settype==1)
	{
		if (s==59)
		{
			s=0;
		}
		s++;
	}
	else if(settype==2)
	{
		if (m==59)
		{
			m=0;
		}
		m++;
	}
	else if(settype==3)
	{
		if (h==24)
		{
			h=0;
		}
		h++;
	}
	if(alarmtype==1)
	{
		if(as==59)
		{
			as=0;
		}
		as++;
	}
	else if(alarmtype==2)
	{
		if(am==59)
		{
			am=0;
		}
		am++;
	}
	else if(alarmtype==3)
	{
		if(ah==24)
		{
			ah=0;
		}
		ah++;
	}
}
void timedec()
{
	if(settype==1)
	{
		if(s==0)
		{
			s=59;
		}
		s--;
	}
	if(settype==2)
	{
		if (m==0)
		{
			m=59;
		}
		m--;
	}
	if(settype==3)
	{
		if (h==0)
		{
			h=24;
		}
		h--;
	}
	if(alarmtype==1)
	{
		if (as==0)
		{
			as=59;
		}
		as--;
	}
	if(alarmtype==2)
	{
		if (am==0)
		{
			am=59;
		}
		am--;
	}
	if(alarmtype==3)
	{
		if (ah==0)
		{
			ah=24;
		}
		ah--;
	}
}


void bsp_KeyProc(uchar KeyValue)
{
	timeinc();
	timedec();
	if(KeyValue==1)
	{
		settype++;
		if(settype==4)
		{
			settype=0;
		}
		KeyValue=0;
	}
	else if(KeyValue==2)
	{
		alarmtype++;
		if(alarmtype==4)
		{
			alarmtype=0;
		}
		KeyValue=0;
	}
	else if(KeyValue==3)
	{
		timeinc();
		KeyValue=0;
	}
	else if(KeyValue==4)
	{
		timedec();
		KeyValue=0;
	}

}



void display()	   		//��ʾ����
{
	if(alarmtype>0)
	{
		P2=0xfe;
		P0=seg7[ah/10];	   //1��λ
		delay_ms(1);
		P2=0xfd;
		P0=seg7[ah%10];	   //2��λ
		delay_ms(1);
		P2=0xfb;
		P0=seg7[10];	   //3��λ
		delay_ms(1);
		P2=0xf7;
		P0=seg7[am/10];	   //4��λ
		delay_ms(1);
		P2=0xef;
		P0=seg7[am%10];	   //5��λ
		delay_ms(1);
		P2=0xdf;
		P0=seg7[10];	   //6��λ
		delay_ms(1);
		P2=0xbf;
		P0=seg7[as/10];	   //7��λ
		delay_ms(1);
		P2=0x7f;
		P0=seg7[as%10];	   //8��λ
		delay_ms(1);
	}
	else
	{
		P2=0xfe;
		P0=seg7[h/10];	   //1��λ
		delay_ms(1);
		P2=0xfd;
		P0=seg7[h%10];	   //2��λ
		delay_ms(1);
		P2=0xfb;
		P0=seg7[10];	   //3��λ
		delay_ms(1);
		P2=0xf7;
		P0=seg7[m/10];	   //4��λ
		delay_ms(1);
		P2=0xef;
		P0=seg7[m%10];	   //5��λ
		delay_ms(1);
		P2=0xdf;
		P0=seg7[10];	   //6��λ
		delay_ms(1);
		P2=0xbf;
		P0=seg7[s/10];	   //7��λ
		delay_ms(1);
		P2=0x7f;
		P0=seg7[s%10];	   //8��λ
		delay_ms(1);	
	}
	
}


//��ʱ��
void Timer0_Init()
{
	TMOD|=0X01;
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	ET0=1;
	TR0=1;
	EA=1;
}
void Timer0() interrupt 1
{
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	count++;
}


//������
void main()
{
	led=0;
	sled=0;
	Timer0_Init();
	while(1)
	{
		TimeTim();			  //ʱ�����
		bsp_CheckAlarm();	  //���Ӽ��
		bsp_KeyScan();		  //����ɨ�迴�ĸ�����������
		bsp_KeyProc(KeyValue);//���ݼ�ֵ������Ӧ�ĵ���
		display();			  //�������ʾ
	}
}

